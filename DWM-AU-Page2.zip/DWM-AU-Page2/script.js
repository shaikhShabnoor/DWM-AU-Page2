var borderColorsForPlans = ["#C72129", "#648824", "#1f57a7", "#666666"];
var button;

$(function () {
  initialSteps();
  clickEvents();
});
window.onload = function () {
    $(".slider").slick({
      autoplay: true,
      autoplaySpeed: 2000,
      arrows: false,
      dots: true,
      prevArrow: '<button type="button" class="slick-prev"></button>',
      nextArrow: '<button type="button" class="slick-next"></button>',
      centerMode: false,
      slidesToShow: 1,
      slidesToScroll: 1,
    });
  };
$(window).scroll(function () {
  scrollToTopOfPage();
});
$(window).resize(function () {
  if ($(this).width() < 600) {
    $(".titleContent").hide().parent("td").removeClass("activeTableCell");
    $(".minus").removeClass("showMinusIcon");
    $(".plus").removeClass("showPlusIcon");
    for(var index=5;index<9;index++)
  {
    $("#supportedFeatures").children('div').eq(index-1).hide();
    
  }
  $("#showMore").show();
  $("#showLess").hide();
  }
  else
  {
   
    for(var index=5;index<9;index++)
    {
      $("#supportedFeatures").children('div').eq(index-1).show();
      
    }
  }
});

function clickEvents() {
  $("#showMore").click(function()
  {
    if ($(this).width() < 600) {
    $(this).hide().siblings(".show").show();
    for(var index=5;index<9;index++)
  {
    $("#supportedFeatures").children('div').eq(index-1).show();
  }
}
  });
  $("#showLess").click(function()
  {
    if ($(this).width() < 600) {
    $(this).hide().siblings(".show").show();
    for(var index=5;index<9;index++)
  {
    $("#supportedFeatures").children('div').eq(index-1).hide();
  }
}
  });
  $(".chooseSystemLeft select").change(function () {
    initialiazationDropdown(".chooseSystemLeft");
  });
  $(".chooseSystemRight select").change(function () {
    initialiazationDropdown(".chooseSystemRight");
  });
  $(".plansTab")
    .children()
    .click(function () {
      $(".priceSection").hide().eq($(this).index()).show();
      $(".subscribeBtn")
        .eq($(this).index())
        .show()
        .siblings(".subscribeBtn")
        .hide();
      $(this).addClass("activePlan").siblings().removeClass("activePlan");
    });
  $(".systemDropdown").click(function () {
    let icon = $(this).children(".material-icons");
    icon.toggleClass("dropup").hasClass("dropup")
      ? icon.text("arrow_drop_down")
      : icon.text("arrow_drop_up");
    $(".dropdownContent").slideToggle();
  });
  $(".dropdownIcon")
    .parent("td")
    .click(function () {
      if ($(window).width() > 600) {
        $(this)
          .children(".titleContent")
          .toggle()
          .parent("td")
          .toggleClass("activeTableCell");
          if($(this).parent("tr").siblings("tr").children("td").hasClass("activeTableCell"))
          {
           
            $(this).parent("tr").siblings("tr").
            children(".activeTableCell").children(".plus").toggleClass("showPlusIcon").
            children(".minus").toggleClass("showMinusIcon");
            $(this).parent("tr").siblings("tr").children("td")
            .removeClass("activeTableCell").children(".titleContent").hide();

          }
          
        $(this).children(".plus").toggleClass("showPlusIcon");
        $(this).children(".minus").toggleClass("showMinusIcon");
      }
    });
 
  
  $(".scrollTopBtn").click(function () {
    $("html, body , document").animate({ scrollTop: 0 }, "slow");
    return false;
  });
  
  $(".firstSelectOption select").change(function () {
    var selected = $(this).children("option:selected").index();
    $(".firstSelectOption").children(".bodyForSelect").eq(selected).show().siblings(".bodyForSelect").hide();
  });

  $(".secondSelectOption select").change(function () {
    var selected = $(this).children("option:selected").index();
    $(".secondSelectOption").children(".bodyForSelect").eq(selected).show().siblings(".bodyForSelect").hide();
  });

  $(".scrollToTop").click(function () {
    $("html, body , document").animate({ scrollTop: 0 }, "slow");
    return false;
  });

  $(".titleOfSystem").click(function () {
    $(".systemReqSection").toggle();
    $("#iconForSystem").toggleClass("rotate");
  })
  $(".benifitsTitle").click(function () {
    $(this).find("img").toggleClass("rotateIcon");
    $(this).siblings(".benifitsSection").toggle();
  })
  
 
  $(".descriptionForPlans").parent("div").click(function () {
    $(this).find("img").toggleClass("rotateIcon");
    $(this).children(".descriptionForPlans").toggle();
  })
  $(".benifitsSection").children("div").not("#secTitle").click(function(){
    $(this).siblings().children("img").removeClass("rotateIcon").siblings(".descriptionForPlans").hide()})
  $("#firstRadio,#secondRadio").click(function () {

    $(this).attr("id") == "firstRadio" ? 
    $(this).parent().siblings("#firstYrPrice,#firstYrLink").show().siblings("#secondYrPrice,#secondYrLink").hide() : 
    $(this).parent().siblings("#secondYrPrice,#secondYrLink").show().siblings("#firstYrPrice,#firstYrLink").hide();
    $(this).find(".radioBtn").attr("id", "selected");
    $(this).siblings("div").find(".radioBtn").attr("id", "notSelected");
  })
}

function initialSteps() {
  $("#showLess").hide();
  if ($(this).width() < 600) {
   
    for(var index=5;index<9;index++)
  {
    $("#supportedFeatures").children('div').eq(index-1).hide();
    
  }
  }

    $(".descriptionForPlans").hide();
  $(".benifitsSection").hide();
  $(".bodyForSelect").hide();
  $(".firstSelectOption .bodyForSelect").eq(0).show();
  $(".secondSelectOption .bodyForSelect").eq(0).show();


  $(".subscribeBtn").eq(0).show().siblings(".subscribeBtn").hide();
  var planTabs = $("#chartHeading ~ td");
  for (var i = 0; i < planTabs.length; i++) {
    planTabs.eq(i).css("border-top", "5px solid " + borderColorsForPlans[i]);
  }
  $(".plansTab").children().eq(0).addClass("activePlan");
  $(".priceSection").eq(0).show();
  $(".chooseSystemRight .contentForSystem").eq(0).show();
  $(".chooseSystemLeft .contentForSystem").eq(0).show();
  $(".systemDropdown").children(".material-icons").addClass("dropup");
  $(".dropdownIcon").parent("td").addClass("pointer");

  scrollToTopOfPage();
}
function initialiazationDropdown(x) {
  $(x + " .contentForSystem")
    .eq($(x + " select option:selected").index())
    .show()
    .siblings()
    .not(":first-child")
    .hide();
}


function scrollToTopOfPage() {
  $(document).scrollTop() >= 20
    ? $(".scrollTopBtn").css("display", "block")
    : $(".scrollTopBtn").css("display", "none");
}
